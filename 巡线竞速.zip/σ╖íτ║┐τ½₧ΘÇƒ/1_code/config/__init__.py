"""
Config package for RoboMaster S1 line follower parameters
"""
